package com.example.androidlabs;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.app.Activity;
import android.util.Log;
import android.os.Bundle;
import android.widget.EditText;

public class LoginActivity extends Activity {
    protected static final String ACTIVITY_NAME = "LoginActivity";
    private Button button_login;
    private EditText emailInput,passwordInput;
    private SharedPreferences pref;
    private SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(ACTIVITY_NAME, "In onCreate()");
        setContentView(R.layout.activity_login);
        /* References to View + Find for Objects in the Design */
        button_login = (Button) findViewById(R.id.btnLogin);
        emailInput = (EditText) findViewById(R.id.emailAddrs);
        passwordInput = (EditText) findViewById(R.id.passLogin);
        /* SharedPreferences Reference */
        pref = getSharedPreferences("userInfo",MODE_PRIVATE);
        String get_email = pref.getString("DefaultEmail","email@domain.com");
        emailInput.setText(get_email);
        /* Callback function for the Login Button */
        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor = pref.edit();
                editor.putString("DefaultEmail",emailInput.getText().toString());
                editor.commit();
                Intent intent = new Intent(LoginActivity.this, StartActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(ACTIVITY_NAME, "In onResume()");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(ACTIVITY_NAME, "In onStart()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(ACTIVITY_NAME, "In onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(ACTIVITY_NAME, "In onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(ACTIVITY_NAME, "In onDestroy()");
    }
}
