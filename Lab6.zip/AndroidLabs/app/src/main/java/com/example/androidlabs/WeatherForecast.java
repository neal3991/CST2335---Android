package com.example.androidlabs;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherForecast extends Activity {
    protected static final String ACTIVITY_NAME = "WeatherForecast";

    ImageView imageV;
    TextView currTempV;
    TextView maxTempV;
    TextView minTempV;

    ProgressBar progress_bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_forecast);

        imageV = (ImageView) findViewById(R.id.weatherImage);
        currTempV = (TextView) findViewById(R.id.currentTemp);
        maxTempV = (TextView) findViewById(R.id.maxTemp);
        minTempV = (TextView) findViewById(R.id.minTemp);
        currTempV = (TextView) findViewById(R.id.currentTemp);
        progress_bar = (ProgressBar) findViewById(R.id.progressBar);

        progress_bar.setVisibility(View.VISIBLE);
        /* Start Executing ForecastQuery */
        new ForecastQuery().execute();
    }

    /* Inner Class Forecast Query*/
    public class ForecastQuery extends AsyncTask<String, Integer, String> {
        String minTemp;
        String maxTemp;
        String weatherStatus;
        String currentTemp;
        private Bitmap bm;

        @Override
        protected String doInBackground(String... strings) {

            InputStream streamInput;
            try {
                URL url = new URL("http://api.openweathermap.org/data/2.5/weather?q=ottawa,ca&APPID=d99666875e0e51521f0040a3d97d0f6a&mode=xml&units=metric");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                // Starts the query
                conn.connect();
                streamInput = conn.getInputStream();

                XmlPullParser parser = Xml.newPullParser();
                parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
                parser.setInput(streamInput, null);
                parser.nextTag();

                int typeOfWeather = parser.getEventType();

                while (typeOfWeather != XmlPullParser.END_DOCUMENT) {
                    //while(parser.next() != XmlPullParser.END_TAG) {

                    if (typeOfWeather != XmlPullParser.START_TAG) {
                        typeOfWeather = parser.next();
                        continue;
                    } else {
                        if (parser.getName().equals("temperature")) {
                            currentTemp = parser.getAttributeValue(null, "value");

                            publishProgress(25);
                            maxTemp = parser.getAttributeValue(null, "max");

                            publishProgress(50);
                            minTemp = parser.getAttributeValue(null, "min");

                        } else if (parser.getName().equals("weather")) {

                            weatherStatus = parser.getAttributeValue(null, "icon");
                        }
                        typeOfWeather = parser.next();
                    }
                } /* While - END*/
                conn.disconnect();
                /* IMAGE Does not exist */
                //looking for a weather image and if it exists
                if (fileExistance(weatherStatus + ".png")) {

                    Log.i(ACTIVITY_NAME, "Image already exists, extracting from Local");

                    File file = getBaseContext().getFileStreamPath(weatherStatus + ".png");
                    FileInputStream fis = new FileInputStream(file);
                    bm = BitmapFactory.decodeStream(fis);



                } else { //imagine doesn't exist.

                    Log.i(ACTIVITY_NAME, "Image does not exists, downloading from website");

                    URL imageUrl = new URL("http://openweathermap.org/img/w/" + weatherStatus+ ".png");
                    conn = (HttpURLConnection) imageUrl.openConnection();
                    conn.connect();
                    streamInput = conn.getInputStream();
                    bm = BitmapFactory.decodeStream(streamInput);

                    FileOutputStream outputStream = openFileOutput(weatherStatus + ".png", Context.MODE_PRIVATE);
                    bm.compress(Bitmap.CompressFormat.PNG, 80, outputStream);

                    outputStream.flush();
                    outputStream.close();

                    conn.disconnect();
                }

                publishProgress(100);

            } catch (IOException e) {
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                e.printStackTrace();
            }
            return null;
        }/* doInBackground - END */

        public boolean fileExistance(String fname){
            File file = getBaseContext().getFileStreamPath(fname);
            return file.exists();   }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);

            progress_bar.setVisibility(View.VISIBLE);
            progress_bar.setProgress(values[0]);

        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

// update the GUI components with the min, max, and current temperature
            currTempV.setText("Current temperature:" + currentTemp + "Celcius ");
            maxTempV.setText("Max temperature: " + maxTemp + " Celcius ");
            minTempV.setText("Min temperature: " + minTemp + "Celcius ");
            imageV.setImageBitmap(bm);
            progress_bar.setVisibility(View.INVISIBLE);

        }
    }

}
